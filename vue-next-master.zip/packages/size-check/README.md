# Size Check

This package is private and is used for checking the baseline runtime size after tree-shaking (with only the bare minimal code required to render something to the screen).
