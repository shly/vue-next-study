let activeEffectScope
class Effect {
  active = true
  constructor(name) {
    this.name = name
  }
  on() {
    if (this.active) {
      activeEffectScope = this
    }
  }
}
const test1 = new Effect('test1')
const test2 = new Effect('test2')
test1.on()
console.log(activeEffectScope)

